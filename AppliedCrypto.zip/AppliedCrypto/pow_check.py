import sys, hashlib, time, math, random

def displayHelp():
  print "you can run python pow_check.py sha1 10 as an example" #generate a hash with 10 zeros
  print "Supported algorithms: " + str(hashlib.algorithms)
  sys.exit()

#check the command line arguments
if len(sys.argv) < 3:
  displayHelp()

hashtype = sys.argv[1]
target_zeros = "0" * int(sys.argv[2])

try:
  hl = hashlib.new(hashtype)
except ValueError:
  print "Unsupported hash type " + hashtype
  displayHelp()

nr_to_hash = random.randint(1000000, 100000000)
hl.update(str(nr_to_hash))

start_time = time.time()

while not bin(int(hl.hexdigest(),16)).endswith(target_zeros):
  nr_to_hash = nr_to_hash + 1
  hl = hashlib.new(hashtype)
  hl.update(str(nr_to_hash))

time_diff = time.time() - start_time

print "The desired hash found in %s seconds.\nThe hash is %s(%s) = %s" % (time_diff, hashtype, nr_to_hash, bin(int(hl.hexdigest(),16)))
