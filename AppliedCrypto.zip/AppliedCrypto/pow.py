#When we use the proof of work concept we challenge the other party to do some work that usually takes a given time.
#This can be done by requiring an input for a fixed hash function that gives result matching the challenger's restriction. 
#The program I would like you to write should calculate restrictions that sufficient for proving X seconds of work.
#The input should be 
#   * the hash function (it can be constant like SHA)
#   * X -- the time that the work we want to prove takes
#The result is the restriction. For example the restriction can be that how many zeros should 
#be at the end of the hash for the right input (which is the proof).

import sys, hashlib, time, math

def displayHelp():
  print "you can run python pow.py sha1 10 as an example" # The number of zeros required to proove 10.0 seconds of work with a sha1 hash
  print "Supported algorithms: " + str(hashlib.algorithms)
  sys.exit()

#check the command line arguments
if len(sys.argv) < 3:
  displayHelp()

hashtype = sys.argv[1]
desired_time = float(sys.argv[2])

try:
  hl = hashlib.new(hashtype)
except ValueError:
  print "Unsupported hash type " + hashtype
  displayHelp()

#calculate 1000 hashes to get the time of one hash
start_time = time.time()
for i in range(1000):
  hl = hashlib.new(hashtype)
  hl.update(str(i))
time_diff = time.time() - start_time
time_of_one_hash = time_diff / 1000
nr_of_hashes = desired_time / time_of_one_hash
nr_of_zeros = math.ceil((math.log(nr_of_hashes) + math.log(2)) / math.log(2)) #always round up to be on the safe side

print "The number of zeros required to proove %s seconds of work with %s type of hashes is %s" % (desired_time, hashtype, nr_of_zeros)
